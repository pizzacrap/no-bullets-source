﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy2 : MonoBehaviour {

	// Variables
	public float health = 5f;
	public float speed = 5f;
	public float moveTimeInSeconds = 1f;

	// GameObjects
	public GameObject player;
	public GameObject fake;
	public GameObject powerBall;
	public GameObject nice;
	public GameObject explosion;

	// Components
	Rigidbody2D reggie;
	SpriteRenderer spr;

	void Start () {
		// Player
		player = GameObject.FindGameObjectWithTag ("Player");
		// GetComponents
		reggie = GetComponent <Rigidbody2D> ();
		spr = GetComponent <SpriteRenderer> ();
		// Start moving towards player
		Invoke ("Move", moveTimeInSeconds);
	}

	void Update () {
		// Hit effects
		transform.localScale = Vector3.Lerp (transform.localScale, new Vector3 (5f, 5f, 0f), 0.25f);

		// Dieing
		if (health <= 0f) {
			Instantiate (nice, new Vector3 (transform.position.x, transform.position.y + 1, 0f), transform.rotation);
			for (float i = 0; i < 10; i++) {
				Instantiate (powerBall, transform.position, transform.rotation);
			}
			GameObject.Destroy (gameObject);
		}
	}

	void FixedUpdate () {
		// Color resetting
		spr.color = new Color (1f, 1f, 1f);
	}

	void Move () {
		fake.transform.right = player.transform.position - fake.transform.position;
		reggie.velocity += new Vector2 (fake.transform.right.x * speed, fake.transform.right.y * speed);

		Invoke ("Move", moveTimeInSeconds);
	}

	void OnTriggerEnter2D (Collider2D other) {
		// Getting hit and taking damage
		if (other.tag == "Bullet") {
			health += -1;
			GameObject.Destroy (other.gameObject);
			// Hit effects
			transform.localScale = new Vector3 (6f, 6f, 0f);
			spr.color = new Color (0f, 0f, 0f);
		}
	}

	void OnCollisionEnter2D (Collision2D other) {
		// Getting hit and taking damage
		if (other.gameObject.tag == "Player") {
			GameObject.Destroy (gameObject);
			Instantiate (explosion, transform.position, transform.rotation);
			GameObject.Destroy (gameObject);
		}
	}
}