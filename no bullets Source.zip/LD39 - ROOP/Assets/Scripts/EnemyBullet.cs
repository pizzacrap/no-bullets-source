﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBullet : MonoBehaviour {

	// Variables
	public float speed = 5;
	public float secondsUntilDestroy = 5f;

	void Start () {
		// Destroy after a few seconds (to prevent lag)
		GameObject.Destroy (gameObject, secondsUntilDestroy);
	}

	void Update () {
		// Move forward forever
		transform.Translate (Vector3.right * speed * Time.deltaTime);
	}

	void OnTriggerEnter2D (Collider2D other) {
		// Destroying if the bullet hits a wall
		if (other.tag == "World") {
			GameObject.Destroy (gameObject);
		}
	}
}