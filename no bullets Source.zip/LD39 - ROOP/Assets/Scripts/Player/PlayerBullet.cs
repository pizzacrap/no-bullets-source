﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBullet : MonoBehaviour {

	// Variables
	public float speed = 5;
	public float secondsUntilDestroy = 5f;

	// Audio
	public GameObject audi;

	void Start () {
		// Destroy after a few seconds (to prevent lag)
		GameObject.Destroy (gameObject, secondsUntilDestroy);
		// Audio
		Instantiate (audi, transform.position, transform.rotation);
	}

	void Update () {
		// Move forward forever
		transform.Translate (Vector3.right * speed * Time.deltaTime);
	}

	void OnTriggerEnter2D (Collider2D other) {
		// Destroying if the bullet hits a wall
		if (other.gameObject.tag == "World") {
			GameObject.Destroy (gameObject);
		}
	}
}