﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerShoot : MonoBehaviour {

	// Script
	PlayerMovement pm;
	
	// Shoot time
	public float timeUntilShoot = 50f;
	float currentTime = 0f;

	// Bullet
	public Transform bullet;

	// Look at mouse fake transform variable
	public Transform tranforsm;

	// Health
	public float hpToTake = 1f;

	void Start () {
		pm = GetComponent <PlayerMovement> ();
	}

	void Update () {
		// Look to mouse
		Vector3 mouseScreen = Input.mousePosition;
		Vector3 mouse = Camera.main.ScreenToWorldPoint(mouseScreen);
		tranforsm.rotation = Quaternion.Euler (0, 0, Mathf.Atan2 (mouse.y - transform.position.y, mouse.x - transform.position.x) * Mathf.Rad2Deg - 90);

		// Shoot towards mouse
		currentTime += 1f;
		if (Input.GetMouseButton (0)) {
			if (currentTime > timeUntilShoot) {
				Instantiate (bullet, transform.position, tranforsm.rotation * Quaternion.Euler (0, 0, 90));
				pm.HealthReduce (-hpToTake);
				currentTime = 0f;
			}
		}
	}
}