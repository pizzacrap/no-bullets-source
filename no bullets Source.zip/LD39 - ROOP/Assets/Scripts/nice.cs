﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class nice : MonoBehaviour {

	public float finalSize = 10f;
	public float lerpSpeed = 0.01f;
	public float angle = 20f;
	public Sprite spr1;
	public Sprite spr2;

	SpriteRenderer spr;
	Color col;

	void Start () {
		spr = GetComponent <SpriteRenderer> ();
		if (Random.Range (0, 2) == 1) {
			if (Random.Range (0, 2) == 1) {
				spr.sprite = spr1;
			} else {
				spr.sprite = spr2;
			}
		}

		col = Random.ColorHSV(0f, 1f, 1f, 1f, 0.5f, 1f);
		spr.color = col;
		transform.Rotate (new Vector3 (0, 0, Random.Range (-angle, angle)));
	}

	void Update () {
		transform.localScale = new Vector3 (Mathf.Lerp (transform.localScale.x, finalSize, lerpSpeed), Mathf.Lerp (transform.localScale.y, finalSize, lerpSpeed), 0f);
	}
}