﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerBallAudio : MonoBehaviour {

	// Component
	AudioSource audi;
	// Pitch variable
	public float pitch = 0.2f;

	void Start () {
		audi = GetComponent <AudioSource> ();
		audi.pitch += Random.Range (-pitch, pitch);
		audi.Play ();
	}
}