﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotate : MonoBehaviour {

	public GameObject enemy;
	public GameObject enemy1;
	bool small = false;

	void Start () {
		Invoke ("Small", 3);
		Invoke ("Enemy", 1);
	}

	void Update () {
		// Rotating
		transform.Rotate (0f, 0f, -1f);
		// Small
		if (small == true) {
			transform.localScale = Vector3.Lerp (transform.localScale, new Vector3 (0f, 0f, 0f), 0.05f);
		}
		if (transform.localScale.x <= 0f) {
			GameObject.Destroy (gameObject);
		}

	}

	void Small () {
		transform.localScale += new Vector3 (1f, 1f, 1f);
		small = true;
	}

	void Enemy () {
		if (small == false) {
			if (Random.Range (0, 2) == 1) {
				Instantiate (enemy1, transform.position, Quaternion.identity);
			} else {
				Instantiate (enemy, transform.position, Quaternion.identity);
			}
			Invoke ("Enemy", 1f);
		}
	}
}