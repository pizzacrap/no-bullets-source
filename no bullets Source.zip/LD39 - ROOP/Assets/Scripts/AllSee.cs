﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AllSee : MonoBehaviour {

	public float spawnTimeInSeconds = 20f;
	public GameObject spawner;

	void Start () {
		Invoke ("SpawnEm", spawnTimeInSeconds);
		Invoke ("DifficultIncrease", 10f);
	}

	void SpawnEm () {
		if (Random.Range (0, 4) == 1) {
			Instantiate (spawner, new Vector3 (12f, 4f, 0f), Quaternion.identity);
		} else if (Random.Range (0, 4) == 1) { 
			Instantiate (spawner, new Vector3 (7f, -12f, 0f), Quaternion.identity);
		} else {
			Instantiate (spawner, new Vector3 (-14, 6, 0), Quaternion.identity);
		}
		Invoke ("SpawnEm", spawnTimeInSeconds);
	}

	void DifficultIncrease () {
		if (spawnTimeInSeconds > 5) {
			spawnTimeInSeconds += -1f;
		}
		Invoke ("DifficultIncrease", 10f);
	}
}