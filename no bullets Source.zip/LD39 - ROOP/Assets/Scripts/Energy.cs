﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Energy : MonoBehaviour {

	public float finalSize = 10f;
	public float lerpSpeed = 0.01f;
	public float angle = 20f;

	void Start () {
		//transform.rotation += Random.Range (-10f, 10f);
		transform.Rotate (new Vector3 (0, 0, Random.Range (-angle, angle)));
	}

	void Update () {
		transform.localScale = new Vector3 (Mathf.Lerp (transform.localScale.x, finalSize, lerpSpeed), Mathf.Lerp (transform.localScale.y, finalSize, lerpSpeed), 0f);
	}
}