﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerBall : MonoBehaviour {

	// Variables
	float speed = 5;
	bool follow = false;
	// Components
	SpriteRenderer spr;
	// Color
	//Color col;
	// Player
	GameObject player;

	void Start () {
		// Spin it around a random amount
		transform.Rotate (0f, 0f, Random.Range(0f, 360f));
		// Get Component
		spr = GetComponent <SpriteRenderer> ();
		// Random color
		//col = Random.ColorHSV (0f, 1f, 1f, 1f, 0.5f, 1f);
		//spr.color = col;
		// Player
		player = GameObject.FindGameObjectWithTag ("Player");
		// Making it only follow the player after 0.5 seconds
		Invoke ("Follow", 0.5f);
	}

	void Update () {
		if (player != null) {
			if (follow) {
				if (Vector2.Distance (transform.position, player.transform.position) < 5f) {
					speed = Mathf.Lerp (speed, 3, 0.05f);
					transform.right = player.transform.position - transform.position;
				} else {
					speed = Mathf.Lerp (speed, 0, 0.05f);
				}
			} else {
				speed = Mathf.Lerp (speed, 0, 0.05f);
			}
		}
		transform.Translate (Vector3.right * speed * Time.deltaTime);
	}

	void Follow () {
		follow = true;
	}
}