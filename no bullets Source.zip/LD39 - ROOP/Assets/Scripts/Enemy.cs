﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour {

	// Variables
	public float speed = 5f;
	public float moveDistance = 1f;
	public float fireRateInSeconds = 1f;
	public float health = 50f;
	Vector2 targetPos;
	bool isMoving = true;

	// Ray
	private Ray sight;
	public float maxRange = 50;
	GameObject target = null;
	public GameObject player;

	// Components
	Animator anime;
	Rigidbody2D reggie;
	SpriteRenderer spr;

	// Bullet
	public GameObject bullet;

	// Death stuff (things that spawn after death)
	public GameObject powerPack;
	public GameObject powerBall;
	public GameObject nice;

	void Start () {
		// Ray
		player = GameObject.FindGameObjectWithTag ("Player");
		// Get Components
		anime = GetComponent <Animator> ();
		reggie = GetComponent <Rigidbody2D> ();
		spr = GetComponent <SpriteRenderer> ();
		// Move
		Invoke ("MoveRandom", Random.Range (0f, 3f));
		// Shoot
		Invoke ("Shoot", fireRateInSeconds);
	}

	void Update () {
		// Hit effects
		transform.localScale = Vector3.Lerp (transform.localScale, new Vector3 (5f, 5f, 0f), 0.25f);

		// Dieing
		if (health <= 0f) {
			Instantiate (nice, new Vector3 (transform.position.x, transform.position.y + 1, 0f), transform.rotation);
			Instantiate (powerPack, transform.position, transform.rotation);
			for (float i = 0; i < 5; i++) {
				Instantiate (powerBall, transform.position, transform.rotation);
			}
			GameObject.Destroy (gameObject);
		}

		// Raycast
		RaycastHit2D hit = Physics2D.Raycast (transform.position, (player.transform.position - transform.position), maxRange, LayerMask.GetMask("Player") + LayerMask.GetMask("World"));
		if (hit.collider.tag == "Player") {
			isMoving = false;
			anime.SetBool ("Shooting", true);
			target = player;
			targetPos = target.transform.position;
			Debug.DrawRay (transform.position, (player.transform.position - transform.position) * maxRange, Color.black);
		} else {
			isMoving = true;
			anime.SetBool ("Shooting", false);
			target = null;
			Debug.DrawRay (transform.position, (player.transform.position - transform.position) * maxRange, Color.red);
		}

		// Moving around randomly
		if (isMoving == true) {
			if (Vector2.Distance (targetPos, transform.position) > speed * Time.deltaTime) {
				anime.SetBool ("Walking", true);
				Vector2 direction = (targetPos - (Vector2)transform.position).normalized;
				reggie.MovePosition (new Vector2 (transform.position.x, transform.position.y) + direction * speed / 2 * Time.deltaTime);
			} else {
				anime.SetBool ("Walking", false);
			}
		} else {
			anime.SetBool ("Walking", false);
		}
		// Sprite Flippy
		spr.flipX = !(targetPos.x > transform.position.x);
	}

	void FixedUpdate () {
		spr.color = new Color (1f, 1f, 1f);
	}

	void MoveRandom () {
		if (isMoving == true) {
			targetPos = (Vector2)transform.position + new Vector2 (Random.Range (-1f, 1f), Random.Range (-1f, 1f));
		}
		Invoke ("MoveRandom", 2f);
	}

	void Shoot () {
		if (player != null) {
			if (anime.GetBool ("Shooting") == true) {
				Vector2 direction = (targetPos - (Vector2)transform.position).normalized;
				GameObject bull = Instantiate (bullet, transform.position, transform.rotation);
				bull.transform.right = player.transform.position - transform.position;
			}
			Invoke ("Shoot", fireRateInSeconds);
		}
	}

	void OnTriggerEnter2D (Collider2D other) {
		// Getting hit and taking damage
		if (other.tag == "Bullet") {
			health += -1;
			GameObject.Destroy (other.gameObject);
			// Hit effects
			transform.localScale = new Vector3 (6f, 6f, 0f);
			spr.color = new Color (0f, 0f, 0f);
		}
	}
}