﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMove : MonoBehaviour {

	// Camera sway
	public float speed = 1f;
	public float maxRotation = 10f;
	
	// Player
	public Transform player;

	Vector3 targetPos;

	private Vector2 velocity = Vector3.zero;

	void FixedUpdate () {
		targetPos = Camera.main.ScreenToWorldPoint(new Vector2(Input.mousePosition.x, Input.mousePosition.y));
		targetPos = ((player.transform.position + targetPos) / 2 - player.transform.position);

		targetPos = targetPos.normalized * Mathf.Clamp (targetPos.magnitude, 0, 1);

		transform.position = Vector2.SmoothDamp (transform.position, player.transform.position + targetPos, ref velocity, 0.3f, 100, Time.deltaTime);
		transform.position = new Vector3 (transform.position.x, transform.position.y, -6f);

		// Camera Sway
		transform.rotation = Quaternion.Euler(0f, 0f, maxRotation * Mathf.Sin (Time.time * speed));
	}
}