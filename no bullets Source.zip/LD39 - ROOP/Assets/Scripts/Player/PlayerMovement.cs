﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerMovement : MonoBehaviour {

	// Gameobjects
	public Slider powerBar;
	public GameObject energy;
	public GameObject powerBallAudio;

	// Ragdoll
	public GameObject rip;
	public GameObject head;
	public GameObject body;
	public GameObject arm;
	public GameObject legs;
	public GameObject gun;

	// Components
	Rigidbody2D riggie;
	SpriteRenderer spr;
	Animator anime;
	AudioSource audi;

	// Variables
	public float playerSpeed = 5f;
	public float playerHealth = 100f;
	public float powerPackHealth = 20f;
	public float powerBallHealth = 2f;
	public float enemyBulletlHealth = 5f;
	public float explosionBulletlHealth = 10f;

	void Start () {
		// Get components
		riggie = GetComponent <Rigidbody2D> ();
		spr = GetComponent <SpriteRenderer> ();
		anime = GetComponent <Animator> ();
		audi = GetComponent <AudioSource> ();

		// Slider
		powerBar = GameObject.FindGameObjectWithTag ("Slide").GetComponent <Slider> ();
	}

	void Update () {
		// Hit effects
		transform.localScale = Vector3.Lerp (transform.localScale, new Vector3 (5f, 5f, 0f), 0.25f);
		// Clamping the Health
		playerHealth = Mathf.Clamp (playerHealth, 0f, 100f);
		// Setting the Health Bar to equal the Health
		powerBar.value = Mathf.Lerp (powerBar.value, playerHealth, 0.1f);
		// Sprite Flippy
		Vector3 pos = new Vector3(Input.mousePosition.x, Input.mousePosition.y, 0);
		float WorldXPos = Camera.main.ScreenToWorldPoint(pos).x;
		if (WorldXPos > transform.position.x) {
			spr.flipX = false;
		} else {
			spr.flipX = true;
		}
		// Walk animation
		if (riggie.velocity.magnitude == 0) {
			anime.SetBool ("Walking", false);
		} else {
			anime.SetBool ("Walking", true);
		}
		// Dieing
		if (playerHealth <= 0) {
			Instantiate (head, transform.position, transform.rotation);
			Instantiate (legs, transform.position, transform.rotation);
			Instantiate (arm, transform.position, transform.rotation);
			Instantiate (gun, transform.position, transform.rotation);
			Instantiate (body, transform.position, transform.rotation);
			Instantiate (rip, new Vector3 (transform.position.x, transform.position.y + 1f, 0f), transform.rotation);
			GameObject.Destroy (gameObject);
		}
	}

	void FixedUpdate () {
		// Movement
		Vector2 targetVelocity = new Vector2 (Input.GetAxisRaw ("Horizontal"), Input.GetAxisRaw ("Vertical"));
		riggie.velocity = targetVelocity * playerSpeed;
		// Color resetting
		spr.color = new Color (1f, 1f, 1f);
	}

	public void HealthReduce (float reduceBy) {
		playerHealth += reduceBy;
	}

	void OnTriggerEnter2D (Collider2D other) {
		// Power Packs
		if (other.tag == "Power") {
			HealthReduce (powerPackHealth);
			// Create the Energy text
			Instantiate (energy, other.transform.position, transform.rotation);
			// Destroy other
			GameObject.Destroy (other.gameObject);
			// Audio
			audi.Play ();
		}
		// Power Balls
		if (other.tag == "powerbale") {
			HealthReduce (powerBallHealth);
			// Destroy other
			GameObject.Destroy (other.gameObject);
			// Create audio
			Instantiate (powerBallAudio, transform.position, transform.rotation);
		}
		// Enemy Bullet
		if (other.tag == "EnemyBullet") {
			HealthReduce (-enemyBulletlHealth);
			// Destroy other
			GameObject.Destroy (other.gameObject);
			// Hit effects
			transform.localScale = new Vector3 (6f, 6f, 0f);
			spr.color = new Color (0f, 0f, 0f);
		}
		// Explosion Bullet
		if (other.tag == "Explosion") {
			HealthReduce (-explosionBulletlHealth);
			// Hit effects
			transform.localScale = new Vector3 (6f, 6f, 0f);
			spr.color = new Color (0f, 0f, 0f);
		}
	}
}